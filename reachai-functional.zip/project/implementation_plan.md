# Post-Signup Onboarding Wizard

Add a multi-step onboarding flow after sign-up that determines the user's role (Job Seeker vs Employee), collects relevant profile info, and locks the dashboard to their persona.

## Flow Overview

```mermaid
flowchart TD
    A[Sign Up Form] --> B[Onboarding Wizard]
    B --> C{What describes you?}
    C -->|Looking for a job| D[Job Seeker Questions]
    C -->|I'm an employee| E[Employee Questions]
    D --> F[Dashboard — Seeker Persona Locked]
    E --> G[Dashboard — Employee Persona Locked]
    
    H[Sign In] --> I{Has completed onboarding?}
    I -->|Yes| J[Dashboard — Locked to saved persona]
    I -->|No| B
```

### Step 1 — Role Selection (both paths)
Full-screen card with two large clickable options:
- 🔍 **"I'm looking for a job"** — routes to Job Seeker questions
- 🏢 **"I'm a company employee"** — routes to Employee questions

### Step 2a — Job Seeker Questions
| Field | Type | Purpose |
|---|---|---|
| Target job title | Text input | Pre-fills communication templates |
| Key skills | Multi-tag input (comma-separated) | Pre-populates skill matcher |
| Years of experience | Select (0-1, 1-3, 3-5, 5-10, 10+) | Context for AI matching |
| Highest education | Select (High School, Bachelor's, Master's, PhD) | Profile context |
| Preferred companies | Text input | Seeds the contact discovery |

### Step 2b — Employee Questions
| Field | Type | Purpose |
|---|---|---|
| Company name | Text input | Pre-fills referral context |
| Your role / title | Text input | Display in profile |
| Department | Select (Engineering, HR, Marketing, Sales, Product, Design, Other) | Context |
| Years at company | Select (< 1, 1-2, 3-5, 5+) | Profile context |
| Open to referrals? | Toggle (Yes/No) | Enables referral evaluator |

### Step 3 — Dashboard Launch
- Persona switcher in sidebar is **hidden** (user is locked to their type)
- Navigation shows **only** the modules for their persona
- Onboarding data is stored in `state.onboardingData` and `localStorage`
- Returning users skip onboarding (data already saved)

---

## Proposed Changes

### HTML

#### [MODIFY] [index.html](file:///c:/Users/lenovo/Downloads/project/project/index.html)
Add a new `<div id="onboarding-page">` between the login page and the app layout. This contains:
- Step 1: Role selection (two large cards)
- Step 2a: Job Seeker form
- Step 2b: Employee form
- Animated step transitions

---

### CSS

#### [MODIFY] [styles.css](file:///c:/Users/lenovo/Downloads/project/project/styles.css)
Add styles for:
- Onboarding full-screen overlay (same pattern as login page)
- Role selection cards (large, hover-animated)
- Step indicator (dots or progress bar)
- Form fields matching existing login form styles
- Step transitions (slide left/right)

---

### JavaScript

#### [MODIFY] [app.js](file:///c:/Users/lenovo/Downloads/project/project/app.js)
Changes:
1. **`handleSignup()`** → instead of calling `transitionToApp()`, call `transitionToOnboarding()`
2. **New: `transitionToOnboarding()`** — hides login, shows onboarding page
3. **New: `selectRole(role)`** — handles role card click, shows appropriate step 2
4. **New: `completeOnboarding()`** — saves data to `localStorage`, hides onboarding, calls `transitionToApp()` with the locked persona
5. **Modify `transitionToApp()`** — accept optional persona param, hide persona switcher if persona is locked
6. **Modify `switchPersona()`** — respect locked state (don't allow switching if `state.personaLocked`)
7. **New state fields**: `state.personaLocked`, `state.onboardingData`
8. **On page load** — check `localStorage` for existing onboarding data; if found, auto-set persona on login

---

## Open Questions

> [!NOTE]
> **Q1:** Should the "Sign In" flow (returning users) also show the onboarding if they haven't completed it before? The plan assumes yes — login checks localStorage for onboarding data and redirects if missing.

> [!NOTE]
> **Q2:** You currently have 3 personas (Seeker, Employee, University/Placement Officer). The request mentions only Job Seeker and Employee. Should I **remove** the University persona entirely, or keep it hidden for now?

---

## Verification Plan

### Manual Verification
1. Sign up → see onboarding wizard (not dashboard)
2. Select "Looking for a job" → see seeker questions → complete → dashboard shows seeker modules only, no persona switcher
3. Sign up again → select "Employee" → see employee questions → complete → dashboard shows employee modules only
4. Sign in as returning user → skip onboarding → dashboard loads with saved persona
5. Logout → sign up fresh → onboarding appears again
